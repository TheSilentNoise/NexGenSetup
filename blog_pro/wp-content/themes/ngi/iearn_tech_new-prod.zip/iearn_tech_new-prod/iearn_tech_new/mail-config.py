#MAIL_SERVER ='smtp.gmail.com'
#MAIL_USERNAME = 'thesilentnoise.com@gmail.com'
#MAIL_PASSWORD = 'Thesilent@2017'
#MAIL_PORT = 465
#MAIL_USE_TLS = False
#MAIL_USE_SSL= True


MAIL_SERVER ='smtp.iearn.tech'
MAIL_USERNAME = 'admin@iearn.tech'
MAIL_PASSWORD = '^xuGZoP9'
MAIL_PORT = 587
MAIL_USE_TLS = False
MAIL_USE_SSL= False
